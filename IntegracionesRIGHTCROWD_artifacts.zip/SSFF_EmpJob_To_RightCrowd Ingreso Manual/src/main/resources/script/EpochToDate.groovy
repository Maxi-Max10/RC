import com.sap.gateway.ip.core.customdev.util.Message;
    import java.util.*;
    import java.text.SimpleDateFormat

    //import java.text.SimpleDateFormat
    //def dateUnix = 1615204493000
    //Date dateObj =  new Date(((long)dateUnix))
    //def cleanDate = new SimpleDateFormat('yyyy-MM-dd').format(dateObj)
    //println "clean date $cleanDate"
    

def String customFunc(String arg1){
    
    
     //Checkea que la fecha traiga dato
      if (arg1 == "") 
      { 
          //No se debe ejecutar función, rightcrowd recibe el vacio.
      }
      
      else 
      { 
        
        long output = arg1.toLong();
        Date dateObj =  new Date(output);
        //def cleanDate = new SimpleDateFormat('yyyyMMdd').format(dateObj);
        def cleanDate = new SimpleDateFormat('yyyy/MM/dd').format(dateObj);
        
        arg1 = cleanDate;
      } 
    
    return arg1;
}