import com.sap.gateway.ip.core.customdev.util.Message;
    import java.util.*;
    import java.text.SimpleDateFormat

    //import java.text.SimpleDateFormat
    //def dateUnix = 1615204493000
    //Date dateObj =  new Date(((long)dateUnix))
    //def cleanDate = new SimpleDateFormat('yyyy-MM-dd').format(dateObj)
    //println "clean date $cleanDate"
    

def String SplitMailCorporativo(String arg1){
    
    
     //Checkea que la fecha traiga dato
      if (arg1 == "") 
      { 
          //No se debe ejecutar función, rightcrowd recibe el vacio.
      }
      
      else 
      { 
        if (arg1.contains('@')) 
        { 
            //No se debe ejecutar función, rightcrowd recibe el vacio.
          
            def values = arg1.split('@')
            def cuenta = ""
            def dominio = ""
        
            cuenta = values[0];
            dominio = values[1];
        
            if (dominio == "enap.cl" || dominio == "enaprefinerias.cl" || dominio == "sipetrol.cl" || dominio == "mag.enap.cl") 
            {
                arg1 = arg1; //Pasar el valor
            }
            else
            {
                arg1 = arg1;
            }
        
        }
        else
        {
            //No se debe ejecutar función, rightcrowd recibe el vacio.
            arg1 = "";
        }
        
      } 
    
    return arg1;
}