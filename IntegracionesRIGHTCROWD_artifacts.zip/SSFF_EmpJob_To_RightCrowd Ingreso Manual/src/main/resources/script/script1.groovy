import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
   
       def body = message.getBody(String) as String;
       body = body.replaceAll("<LoadCardholder","<rig:LoadCardholder");
       body = body.replaceAll("<cardholder","<rig:cardholder");
       body = body.replaceAll("<CDFs","<rig:CDFs");
       body = body.replaceAll("</cardholder>","</rig:cardholder>");
       body = body.replaceAll("</LoadCardholder>","</rig:LoadCardholder>");
       message.setBody(body);
       return message;
}
