import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
   
       def body = message.getBody(String) as String;
       body = body.replaceAll("ns0:","rig:");
       body = body.replaceAll("ns1:","rig:");
       body = body.replaceAll("xmlns:ns1=","xmlns:rig=")
       body = body.replaceAll("xmlns:ns0=","xmlns:rig=")
       body = body.replaceAll("rig:","")
       message.setBody(body);
       return message;
}
